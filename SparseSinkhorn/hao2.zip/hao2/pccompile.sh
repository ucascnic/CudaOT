#!/bin/bash
#module rm mpi/intel/17.0.5
#module rm intel/17.0.5
#source load.sh
#which mpicc
mpiicpc -fopenmp -march=core-avx2  -limf -Ofast pivot.cpp -o pivot
