#!/bin/bash
#SBATCH	-p IPCC
#SBATCH -c 8
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH -o %j.out


export OMP_NUM_THREADS=8

#mpirun ./pivot uniformvector-2dim-5h.txt
#source load.sh
#mpirun ./pivot $1 #uniformvector-4dim-1h.txt
#./testarma #uniformvector-4dim-1h.txt
./main g-6997-83688.mtx
