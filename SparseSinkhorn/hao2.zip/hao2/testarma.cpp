#include <armadillo>
#include <iostream>
#include <sys/time.h>
#include <omp.h>
#include <vector>

#include <stdio.h>
class TimeIt
{
public:
    timeval start, end;
    double storage;
    TimeIt() : start(), end(), storage(0) {}
    void timestart()
    {
        gettimeofday(&this->start, NULL);
    }
    void timeend(const char *s)
    {
        gettimeofday(&this->end, NULL);
        puts(s);
        printf("Using time : %f ms\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0);
    }

    void stage()
    {
        gettimeofday(&this->end, NULL);
        storage += (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0;
    }

    void pTime(const char *s)
    {
        // puts(s);
        // printf("Using time : %f ms\n", storage);
        std::cout << s << " using time : " << storage << "ms" << std::endl;
    }
};

int main()
{
    TimeIt it;
    it.timestart();
    arma::mat testL(16, 1700000);
    testL.eye();
    arma::mat testR(1700000, 2);
    testR.fill(1);
    arma::mat mul = testL * testR;
    it.timeend("total");
    std::cout << "mul:\n"
              << mul << std::endl;
    std::vector<int> a(16, 0);
    #pragma omp parallel
    {
        int id = omp_get_thread_num();
        ++a[id];
        // std::cout << "my id is " << id << std::endl;
        if(id == 0){
            std::cout << "total thread number is " << omp_get_num_threads() << std::endl;
        }
    }
    for(auto m: a){
        std::cout << m <<" ,";
    }
    std::cout<<std::endl;
    return 0;
}
