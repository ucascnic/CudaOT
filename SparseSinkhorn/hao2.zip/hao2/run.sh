srun -p IPCC -N 1 ./main g-6997-83688.mtx
