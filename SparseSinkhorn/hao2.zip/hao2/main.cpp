
#include <stack>
#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <math.h>
#include <sys/time.h>
#include <omp.h>
#define ROW 0
#define COLUMN 1
#define VALUE 2
#define vertex1 0
#define vertex2 1
#define Weight 2

using namespace std;
#include <string>
bool compare(const vector<double> &a, const vector<double> &b)
{
    return a[2] > b[2];
}
#include <stdio.h>
class TimeIt
{
public:
    timeval start, end, restart;
    double storage;
    TimeIt() : start(), end(), restart(), storage(0) {}
    // TimeIt()
    void timestart()
    {
        gettimeofday(&this->start, NULL);
        gettimeofday(&this->restart, NULL);
    }
    void timeend(const char *s)
    {
        gettimeofday(&this->end, NULL);
        puts(s);
        // std::cout << s << " ";
        
        printf(" time point %f ms, using time %f\n", 
         (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0,
        (end.tv_sec - restart.tv_sec) * 1000 + (end.tv_usec - restart.tv_usec) / 1000.0);
        gettimeofday(&this->restart, NULL);
    }

    void stage()
    {
        gettimeofday(&this->end, NULL);
        storage += (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0;
    }

    void pTime(const char *s)
    {
        // puts(s);
        // printf("Using time : %f ms\n", storage);
        std::cout << s << " using time : " << storage << "ms" << std::endl;
    }
};
#include <armadillo>

int main(int argc, const char *argv[])
{

    TimeIt it = TimeIt();

    // read input file
    const char *file = "byn1.mtx";
    if (argc > 2)
    {
        printf("Usage : ./main <filename>");
        exit(0);
    }
    else if (argc == 2)
    {
        file = argv[1];
    }
    // the matrix you read must be a adjacency matrix
    ifstream fin(file);
    int M, N, L;
    // Ignore headers and comments
    while (fin.peek() == '%')
        fin.ignore(2048, '\n');
    // declare matrix vector, volume and degree
    fin >> M >> N >> L;
    double volume[M + 1]; // volume of every point
    double degree[M + 1]; // degree of every point
    degree[0] = 0;
    volume[0] = 0;
    vector<double> triple;                  // element
    vector<vector<double>> triple1;         // elements in the same column
    vector<vector<vector<double>>> triple2; // the whole matrix

    // fill matrix vector and calculate the degree and volume of every point
    int column = 1;
    int m, n = 0;
    double data = 0;
    int n1 = 1;
    for (int i = 0; i < L; ++i)
    {
        fin >> m >> n >> data;
        // check wether change the column
        if (n1 != n)
        {
            column++;
            // initialization
            volume[column] = 0;
            degree[column] = 0;
            n1 = n;
            triple2.push_back(triple1);
            // clear up the triple1
            triple1.erase(triple1.begin(), triple1.end());
        }
        volume[column] = volume[column] + data;
        degree[column] = degree[column] + 1;
        triple.push_back(m);
        triple.push_back(n);
        triple.push_back(data);
        triple1.push_back(triple);
        triple.erase(triple.begin(), triple.end());
    }
    fin.close();
    triple2.push_back(triple1);
    // free the memory of triple1
    vector<vector<double>>().swap(triple1);

    // show triple1
    //    for (auto i: triple2){
    //        for (auto x : i){
    //            for (auto y : x)
    //                std::cout << y  << " ";

    //            std::cout << std::endl;
    //        }

    //    }

    // show triple2
    //    for (auto i: triple2){
    //        for (auto x : i){
    //            for (auto y : x)
    //                std::cout << y  << " ";

    //            std::cout << std::endl;
    //        }
    //         std::cout << "_______" << std::endl;

    //    }
    // exit(0);
    //
    //    for (auto x : volume){
    //        std::cout << x << " ";
    //        std::cout << std::endl;
    //    }
    //    exit(0);

    /**************************************************/
    /***************** Start timing *******************/
    /**************************************************/
    struct timeval start, end;
    gettimeofday(&start, NULL);

    it.timestart();
    // find the point that has the largest volume
    int largest_volume_point = 0;
    double largest_volume = 0;
    for (int i = 1; i <= M; i++)
    {
        if (volume[i] > largest_volume)
        {
            largest_volume_point = i;
            largest_volume = volume[i];
        }
    }
    std::vector<int> no_weight_distance(M + 1, 0);
    std::cout << "largest_volume_point" << largest_volume_point << std::endl;
    // std::cout << largest_volume << std::endl;
    it.timeend("Find root point with max volumn");

    // run bfs to get the no-weight distance between normal point with the largest-volume point
    queue<int> process; // to show the process of bfs
    // run bfs and calculate the no-weight distance
    int distance = 1;
    int point;
    process.push(largest_volume_point);
    // use 0 to cut the layer
    process.push(0);
    no_weight_distance[largest_volume_point] = -1;
    while (process.size() != 1 || process.front() != 0)
    {
        point = process.front();
        process.pop();
        // set zero to cut near layers
        if (point == 0)
        {
            process.push(0);
            distance++;
            continue;
        }
        for (int i = 0; i < triple2[point - 1].size(); i++)
        {
            if (no_weight_distance[int(triple2[point - 1][i][ROW])] == 0)
            {
                process.push(int(triple2[point - 1][i][ROW]));
                no_weight_distance[int(triple2[point - 1][i][ROW])] = distance;
            }
        }
    }
    no_weight_distance[largest_volume_point] = 0;
    queue<int>().swap(process);
    it.timeend("BFS no-weight distance");

    //    for (auto x : no_weight_distance){
    //        std::cout << x << " " << std::endl;
    //    }exit(0);

    //  到这边就是把最大度的点和其他点的距离算出来  并行

    //    for (int i = 0;i < no_weight_distance.size();++i){
    //        std::cout << no_weight_distance[i] <<  " ";
    //    }
    //    std::cout << std::endl;
    // free the memory

    // construct the edge-weight matrix
    vector<double> edge;
    vector<vector<double>> edge_matrix; // to run the krascal
    for (int i = 0; i < triple2.size(); i++)
    {
        for (int j = 0; j < triple2[i].size(); j++)
        {
            if (triple2[i][j][COLUMN] <= triple2[i][j][ROW])
            {
                break;
            }
            edge.push_back(triple2[i][j][ROW]);
            edge.push_back(triple2[i][j][COLUMN]);
            // push effect valuable into vector
            double a = degree[int(edge[0])];
            double b = degree[int(edge[1])];
            double c = a >= b ? a : b;
            double d = triple2[i][j][VALUE];
            double e = no_weight_distance[int(edge[0])];
            double f = no_weight_distance[int(edge[1])];
            double g = d * log(c) / (f + e);
            edge.push_back(g);
            edge.push_back(d);
            edge_matrix.push_back(edge);
            edge.erase(edge.begin(), edge.end());
        }
    }
    it.timeend("construct 'edge-effective weight' matrix");

    // sort according to the weight of each edge
    stable_sort(edge_matrix.begin(), edge_matrix.end(), compare);
    it.timeend("sort edge by effective weight");

    // run kruscal to get largest-effect-weight spanning tree. Besides construct LG matrix of spanning tree
    int assistance[int(edge_matrix.size()) + 1]; // check wether some points construct the circle
    for (int i = 0; i <= edge_matrix.size(); i++)
    {
        assistance[i] = i;
    }
    int k = 0;                            // show how many trees have been add into
    vector<vector<double>> spanning_tree; // spanning tree
    int tmin;
    int tmax;
    std::vector<int> hight(M + 1, 0);
    arma::umat localcations(2, 2 * M - 2);
    arma::mat values(1, 2 * M - 2);
    arma::mat diag(1, M);
    arma::umat inds(2, M);
    for (int i = 0; i < M; ++i)
    {
        inds(0, i) = i;
        inds(1, i) = i;
    }
    hight[largest_volume_point] = 1; // the parent node
    // kruscal paralllel
    for (int i = 0; i < edge_matrix.size(); i++)
    {
        int e1 = edge_matrix[i][0];
        int e2 = edge_matrix[i][1];
        if (assistance[int(e1)] != assistance[e2])
        {

            localcations(0, 2 * k) = e1 - 1;
            localcations(1, 2 * k) = e2 - 1;
            values(2 * k) = -edge_matrix[i][3];

            localcations(0, 2 * k + 1) = e2 - 1;
            localcations(1, 2 * k + 1) = e1 - 1;
            values(2 * k + 1) = -edge_matrix[i][3];

            diag(e1 - 1) += edge_matrix[i][3];
            diag(e2 - 1) += edge_matrix[i][3];

            k++;
            spanning_tree.push_back(edge_matrix[i]);

            tmin = assistance[int(edge_matrix[i][0])] >= assistance[int(edge_matrix[i][1])] ? assistance[int(edge_matrix[i][1])] : assistance[int(edge_matrix[i][0])];
            tmax = assistance[int(edge_matrix[i][0])] < assistance[int(edge_matrix[i][1])] ? assistance[int(edge_matrix[i][1])] : assistance[int(edge_matrix[i][0])];
            for (int j = 1; j <= int(edge_matrix.size()); j++)
            {
                if (assistance[j] == tmin)
                {
                    assistance[j] = tmax;
                }
            }
        }
        if (k == M - 1)
        {
            break;
        }
    }
    it.timeend("Kruskal build MEWST");

    arma::umat locall = arma::join_horiz(localcations, inds);
    arma::mat valuesall = arma::join_horiz(values, diag);
    arma::sp_mat LG(locall, valuesall, M, N);
    it.timeend("build laplace matrix of spanning tree, using exist data");
    //    for (auto x : assistance){
    //        std::cout << x << " ";
    //    }

    //    std::cout << std::endl;
    //    // print the spanning tree
    //    for (int i = 0;i < spanning_tree.size();++i){
    //        for (int j = 0 ; j < spanning_tree[i].size();++j){
    //            std::cout << spanning_tree[i][j] << " ";

    //        }
    //        std::cout << std::endl;
    //    }
    // laplace matrix

    // Search in  MEWST, from root node. compute vertices' weight distance、parent、height in MEWST.
    // weight distance = sum{1/(egde weight)}
    std::vector<int> parent(M + 1, 0);
    parent[largest_volume_point] = largest_volume_point;
    queue<int> nodes;
    nodes.push(largest_volume_point);
    std::vector<double> weight_distance(M + 1, 0);// start from [1], the 0th  element is abandoned.
    int cnt = 0;
    while (!nodes.empty())
    {
        int node = nodes.front();
        // std::cout << "node" << node << std::endl;
        nodes.pop();
        arma::sp_vec v = LG.col(node - 1);
        v(node - 1) = 0;
        v(parent[node] - 1) = 0;
        auto start = v.begin();
        auto end = v.end();
        for (auto itx = start; itx != end; ++itx)
        {
            int j = itx.row();
            {
                nodes.push(j + 1);
                parent[j + 1] = node;
                weight_distance[j + 1] = weight_distance[node] - 1.0 / LG(j, node - 1);
                hight[j + 1] = hight[node] + 1;
            }
        }
    }
    it.timeend("Search on MEWST, compute weight distance parent and height");

    // construct the off-tree edge
    vector<vector<double>> off_tree_edge;
    int inside = 0; // To show which trees are in the spanning tree
    for (int i = 0; i < edge_matrix.size(); i++)
    {
        if (edge_matrix[i][0] == spanning_tree[inside][0] && edge_matrix[i][1] == spanning_tree[inside][1])
        {//the i-th edge in edge_matrix is on spanning tree
            ++inside;
            // to avoid inside crossing the border of spanning_tree
            if (inside == spanning_tree.size())
            {
                inside--;
            }
            continue;
        }
        off_tree_edge.push_back(edge_matrix[i]);
    }
    vector<vector<double>>().swap(edge_matrix);
    it.timeend("construct off-tree egde");

    // calculate the resistance of each off_tree edge
    vector<vector<double>> copy_off_tree_edge; // to resore the effect resistance
    edge.erase(edge.begin(), edge.end());
    for (int i = 0; i < off_tree_edge.size(); i++)
    {
        edge.push_back(off_tree_edge[i][0]);
        edge.push_back(off_tree_edge[i][1]);
        int point1 = off_tree_edge[i][0];
        int point2 = off_tree_edge[i][1];
        int p1 = point1;
        int p2 = point2;
        double x = 0.0;
        while (hight[p1] < hight[p2])
        {
            {
                p2 = parent[p2];
                // x += 1.0;
            }
        }
        while (hight[p1] > hight[p2])
        {
            {
                p1 = parent[p1];
                // x += 1.0;
            }
        }

        if (p1 == p2)
        {
            x = weight_distance[point1] + weight_distance[point2] - 2.0 * weight_distance[p1];
        }
        else
        {

            while (1)
            {
                if (p1 == p2)
                {
                    // x += 2.0;
                    x = weight_distance[point1] + weight_distance[point2] - 2.0 * weight_distance[p1];
                    break;
                }
                // x += 2.0;
                p1 = parent[p1];
                p2 = parent[p2];
            }
        }
        double xx = x;
        edge.push_back(xx * off_tree_edge[i][3]);
        edge.push_back(off_tree_edge[i][3]);
        copy_off_tree_edge.push_back(edge);
        edge.erase(edge.begin(), edge.end());
    }
    // std::cout << "done" << std::endl;
    it.timeend("compute 'effective resistance*egde weight' ");

    // sort by effect resistance
    vector<vector<double>>().swap(off_tree_edge);
    stable_sort(copy_off_tree_edge.begin(), copy_off_tree_edge.end(), compare);
    it.timeend("sort off-tree edge by 'effective resistance*egde weight'");

    
    int Noff = copy_off_tree_edge.size();
    // arma::umat offtreelocation(2, 2 * Noff);
    // arma::umat offvalues(1, 2 * Noff);
    arma::umat OFLG_dense(M, N);
    for (int i = 0; i < Noff; ++i)
    {
        int p1 = copy_off_tree_edge[i][0] - 1;
        int p2 = copy_off_tree_edge[i][1] - 1;
        // offtreelocation(0, 2 * i) = p1;
        // offtreelocation(1, 2 * i) = p2;
        // offtreelocation(0, 2 * i + 1) = p2;
        // offtreelocation(1, 2 * i + 1) = p1;
        // offvalues(2 * i) = i;
        // offvalues(2 * i + 1) = i;
        OFLG_dense(p1, p2) = i;
        OFLG_dense(p2, p1) = i;
    }
    it.timeend("initialize OFLG_dense");

    // arma::sp_umat OFLG(offtreelocation, offvalues, M, N);
    // arma::umat OFLG_dense(OFLG);

    //    std::cout << offvalues << std::endl;
    //    std::cout << offtreelocation << std::endl;
    //    std::cout << OFLG << std::endl;exit(0);

    // add some edge into spanning tree
    int num_additive_tree = 0;
    int similarity_tree[copy_off_tree_edge.size()]; // check whether a edge is similar to the edge added before
    for (int i = 0; i < copy_off_tree_edge.size(); i++)
    {
        similarity_tree[i] = 0;
    }
    it.timeend("initilize similarity tree");

    TimeIt time_bfs, time_bfs1, time_bfs2, time_marksimilary;
    for (int i = 0; i < copy_off_tree_edge.size(); i++)
    {
        // if there has enough off-tree edge added into spanning tree, the work has been finished
        if (num_additive_tree == max(int(copy_off_tree_edge.size() / 25), 2))
        {
            break;
        }
        // if adge is not the similar tree,you can add it into spanning tree
        if (similarity_tree[i] == 0)
        {
            num_additive_tree++;
            /**** Iteration Log. Yuo delete the printf call. ****/
            // if ((num_additive_tree % 64) == 0)
            // {
            //     printf("num_additive_tree : %d\n", num_additive_tree);
            // }
            spanning_tree.push_back(copy_off_tree_edge[i]);

            int belta2 = 0;
            int p1 = copy_off_tree_edge[i][0];
            int p2 = copy_off_tree_edge[i][1];

            while (hight[p1] < hight[p2])
            {
                {
                    p2 = parent[p2];
                }
            }
            while (hight[p1] > hight[p2])
            {
                {
                    p1 = parent[p1];
                }
            }

            if (p1 == p2)
            {
                belta2 = 1;
            }
            else
            {
                while (1)
                {
                    if (p1 == p2)
                    {
                        break;
                    }
                    p1 = parent[p1];
                    p2 = parent[p2];
                    belta2++;
                }
            }
            int belta = belta2;

            time_bfs.timestart();
            time_bfs1.timestart();
            // choose two nodes as root node respectively to run belta bfs
            vector<int> bfs_process1;
            bfs_process1.push_back(copy_off_tree_edge[i][0]);
            // use zero to cut the near layer
            bfs_process1.push_back(0);
            int mark1[M + 1];
            for (int j = 0; j < M + 1; j++)
            {
                mark1[j] = 0;
            }
            mark1[int(copy_off_tree_edge[i][0])] = 1;
            int laywer = 0;

            for (int j = 0; j < M; j++)
            {
                if (laywer == belta)
                {
                    break;
                }
                if (bfs_process1[j] == 0)
                {
                    bfs_process1.push_back(0);
                    laywer++;
                }
                else
                {
                    auto start = LG.begin_col(bfs_process1[j] - 1);
                    auto end = LG.end_col(bfs_process1[j] - 1);
                    for (auto itx = start; itx != end; ++itx)
                    {
                        auto col_i = itx.row() + 1;
                        if (mark1[col_i] == 0)
                        {
                            bfs_process1.push_back(col_i);
                            mark1[col_i] = 1;
                        }
                    }
                    // for (int x = 0; x < M; x++)
                    // {
                    //     if (LG(bfs_process1[j] - 1, x) == 0)
                    //     {
                    //         continue;
                    //     }
                    //     else if (mark1[x + 1] == 0 && x + 1 != bfs_process1[j] && x + 1 != copy_off_tree_edge[i][0])
                    //     {
                    //         bfs_process1.push_back(x + 1);
                    //         mark1[x + 1] = 1;
                    //     }
                    // }
                }
            }
            time_bfs1.stage();
            time_bfs2.timestart();
            vector<int> bfs_process2;
            bfs_process2.push_back(copy_off_tree_edge[i][1]);
            // use zero to cut the near layer
            bfs_process2.push_back(0);
            int mark2[M + 1];
            for (int j = 0; j < M + 1; j++)
            {
                mark2[j] = 0;
            }
            mark2[int(copy_off_tree_edge[i][1])] = 1;
            laywer = 0;

            for (int j = 0; j < M; j++)
            {
                if (laywer == belta)
                {
                    break;
                }
                if (bfs_process2[j] == 0)
                {
                    bfs_process2.push_back(0);
                    laywer++;
                }
                else
                {
                    auto start = LG.begin_col(bfs_process2[j] - 1);
                    auto end = LG.end_col(bfs_process2[j] - 1);
                    for (auto itx = start; itx != end; ++itx)
                    {
                        auto col_i = itx.row() + 1;
                        if (mark2[col_i] == 0)
                        {
                            bfs_process2.push_back(col_i);
                            mark2[col_i] = 1;
                        }
                    }
                    // for (int x = 0; x < M; x++)
                    // {
                    //     if (LG(bfs_process2[j] - 1, x) == 0)
                    //     {
                    //         continue;
                    //     }
                    //     else if (mark2[x + 1] == 0 && x + 1 != bfs_process2[j] && x + 1 != copy_off_tree_edge[i][1])
                    //     {
                    //         bfs_process2.push_back(x + 1);
                    //         mark2[x + 1] = 1;
                    //     }
                    // }
                }
            }
            time_bfs2.stage();
            time_bfs.stage();

            // mark the edge that is similar to the edge which wants to be added
            time_marksimilary.timestart();
            for (int j = 0; j < bfs_process1.size(); j++)
            {
                if (bfs_process1[j] == 0)
                {
                    continue;
                }
                for (int k = 0; k < bfs_process2.size(); k++)
                {
                    if (bfs_process2[k] == 0)
                    {
                        continue;
                    }
                    int p1 = bfs_process1[j] - 1;
                    int p2 = bfs_process2[k] - 1;
                    int location = OFLG_dense(p1, p2);
                    if (location)
                    {
                        similarity_tree[location] = 1;
                    }
                }
            }
            time_marksimilary.stage();
        }
    }
    it.timeend("recover edges");

    gettimeofday(&end, NULL);
    time_bfs1.pTime("bfs1 ");
    time_bfs2.pTime("bfs2 ");
    time_bfs.pTime("BFS ");
    time_marksimilary.pTime("Mark similar edge ");
    printf("Using time : %f ms\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0);

    /**************************************************/
    /******************* End timing *******************/
    /**************************************************/

    FILE *out = fopen("result.txt", "w");
    for (int i = 0; i < spanning_tree.size(); i++)
    {
        fprintf(out, "%d %d\n", int(spanning_tree[i][0]), int(spanning_tree[i][1]));
    }
    fclose(out);
    return 0;
}
