
source /public1/soft/modules/module.sh

module load cmake/3.23.1   
source /public1/soft/oneAPI/2022.1/setvars.sh intel64 

module load gcc/10.2.0

#export OMP_DYNAMIC=FALSE
#export OMP_PROC_BIND=TRUE
#export OMP_NESTED=TRUE
